package ru_mirea_buynachev_lab2;

public class TestAuthor {
    public static void main(String[] args) {
        Author a1 = new Author("Nesbo", "nesbo.north@mail.ru", 'M');
        System.out.println(a1);
    }
}
