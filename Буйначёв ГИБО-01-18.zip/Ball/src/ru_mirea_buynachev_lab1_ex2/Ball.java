package ru_mirea_buynachev_lab1_ex2;
import java.lang.*;

public class Ball {
    private String radius;
    private String volume;
    private String color;

    public Ball(String radius, String volume, String color) {
        this.radius = radius;
        this.volume = volume;
        this.color = color;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Ball{" +
                "radius='" + radius + '\'' +
                ", volume='" + volume + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}
