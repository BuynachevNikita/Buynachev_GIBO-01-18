package ru_mirea_buynachev_lab1_ex2;

public class demoBall {
    public static void main(String[] args) {
        Ball b1 = new Ball("Ten", "Five", "green");
        System.out.println(b1);
    }
}
