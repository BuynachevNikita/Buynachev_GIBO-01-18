package ru_mirea_buynachev_lab1_ex3;

public class demoBook {
    public static void main(String[] args) {
        Book q1 = new Book("Son", "Nesbo", 524);
        System.out.println(q1);
    }
}
