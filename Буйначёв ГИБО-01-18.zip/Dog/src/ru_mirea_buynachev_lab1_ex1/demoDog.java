package ru_mirea_buynachev_lab1_ex1;

public class demoDog {
    public static void main(String[] args) {
        Dog d1 = new Dog("Rich", "Doberman", 3.5);
        System.out.println(d1);
    }
}
